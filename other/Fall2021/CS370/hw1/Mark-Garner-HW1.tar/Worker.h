#ifndef WORKER_H_INCLUDED
#define WORKER_H_INCLUDED

int random_in_range(int lower_bound, int upper_bound);
int get_divisibility_count(int *array, int arraySize, int upperBound);
float get_running_ratio();
#endif
