This file contains only this README.txt file and the python code shceduler.py.

Questions:
1. The other name for the Shortest Job First algorithm is Shortest Job Next
2. New, Ready, Running, Blocked/Waiting, Exit
3. Shortest Job First is like Priority Scheduling with the priority based on remaining time of the process
4. Convoy effect is the primary disadvantage of First Come First Serve Scheduling algorithm
5. It prevents starvation by moving waiting process higher in the priority queue