README:
This code encrypts and decryptes messages using block and stream ciphers.
This package includes the following:
Main.cc
README.txt
Makefile

The name of the executable is ./hw1
hence, you run the code like so:
./hw1 ('B'|'S') inputFile outputFile keyFile ('E'|'D')