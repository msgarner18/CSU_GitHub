/********************************************************************************
 * Each instance of a consumer reads a letter from the buffer, reports the
 * location and the time the letter was read from the buffer, and appends each
 * letter to consumerStr.
 ********************************************************************************/
public class Consumer extends java.lang.Thread {
    Bdbuffer buffer;// used to access letters produced by producers
    String consumerStr;// contains all letters produced
    int letterNum;// number of letters the consumer will consume
    int id;// number used to differentiate each consumer instance

    public Consumer(Bdbuffer _buffer, int _letterNum, int _id) {
        buffer = _buffer;
        consumerStr = "";
        letterNum = _letterNum;
        id = _id;
    }

    public String getConsumedStr() {
        return consumerStr;
    }

    @Override
    public void run() {
        // consume letterNum letters
        for (int i = 0; i < letterNum; i++) {
            // attempt to consume a letter
            char letter = buffer.dequeue(id);

            // if it worked, add letter to consumerStr
            if (letter != '!')
                consumerStr += letter;
            // if it didn't work, try again
            else
                i--;
        }
    }
}