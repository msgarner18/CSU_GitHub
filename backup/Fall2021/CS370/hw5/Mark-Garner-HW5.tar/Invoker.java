import java.lang.Exception;
import java.util.Random;
import java.util.Arrays;

/********************************************************************************************
 * This is the driver program which will be used to create an instance of the
 * Circular buffer, and create and wait for producer and consumer threads.
 ********************************************************************************************/
class Invoker {
    public static void main(String[] args) {
        validateArgs(args);

        // define randomWithSeed based on seed
        int seed = Integer.parseInt(args[0]);
        Random randomWithSeed = new Random(seed);

        // randomly define needed values based on randomWithSeed
        int bufferSize = randomWithSeed.nextInt(6) + 5;
        int itemNum = randomWithSeed.nextInt(11) + 10;
        int consNum = randomWithSeed.nextInt(4) + 2;
        int prodNum = randomWithSeed.nextInt(4) + 2;
        Bdbuffer buffer = new Bdbuffer(bufferSize);

        // print randomly defined values to terminal
        printInitVals(bufferSize, itemNum, prodNum, consNum);

        // start producers and consumers and print results when done
        produceAndConsume(buffer, prodNum, consNum, itemNum, seed);
    }

    // Ensures that arguments are valid
    public static void validateArgs(String[] args) {
        if (args.length != 1) {
            System.out.println("Must supply exactly 1 argument!");
            System.exit(1);
        }
        try {
            Integer.parseInt(args[0]);
        } catch (java.lang.NumberFormatException e) {
            System.out.println("Argument must be an integer!");
            System.exit(1);
        }
    }

    // prints arguments provided in desired format
    public static void printInitVals(int bufferSize, int itemNum, int prodNum, int consNum) {
        System.out.println("[Invoker] Buffer Size: " + bufferSize);
        System.out.println("[Invoker] Total Items: " + itemNum);
        System.out.println("[Invoker] No. of producers: " + prodNum);
        System.out.println("[Invoker] No. of consumers: " + consNum);
    }

    // creates and returns an array of producers based on:
    // buffer: what buffer the producers should use
    // prodNum: Number of producers you wish to create
    // totItemNum: total number of items you want processed (these will be split
    // evenly between all producers)
    // seed: seed for the randomly produced values
    public static Producer[] fillProducers(Bdbuffer buffer, int prodNum, int totLetterNum, int seed) {
        Producer[] producers = new Producer[prodNum];

        for (int i = 0; i < prodNum; i++) {
            int letterNum = totLetterNum / prodNum;
            if (i == 0)
                letterNum += totLetterNum % prodNum;
            producers[i] = new Producer(buffer, letterNum, i + 1, seed);
        }

        return producers;
    }

    // creates and returns an array of consumers based on:
    // buffer: what buffer the consumers should use
    // consNum: Number of consumers you wish to create
    // totItemNum: total number of items you want consumed (these will be split
    // evenly between all consumers)
    public static Consumer[] fillConsumers(Bdbuffer buffer, int consNum, int totLetterNum) {
        Consumer[] consumers = new Consumer[consNum];

        for (int i = 0; i < consNum; i++) {
            int letterNum = totLetterNum / consNum;
            if (i == 0)
                letterNum += totLetterNum % consNum;
            consumers[i] = new Consumer(buffer, letterNum, i + 1);
        }

        return consumers;
    }

    // start all threads in array arr. (producer or consumer)
    public static void start(Thread[] arr) {
        for (int i = 0; i < arr.length; i++)
            arr[i].start();
    }

    // join all threads in array arr. (producer or consumer)
    public static void join(Thread[] arr) {
        for (int i = 0; i < arr.length; i++) {
            try {
                arr[i].join();
            } catch (InterruptedException e) {
                System.out.println(e);
                System.exit(1);
            }
        }
    }

    // takes a string and returns it sorted a-z
    public static String sortString(String myString) {
        char[] array = myString.toCharArray();
        Arrays.sort(array);

        return new String(array);
    }

    // iterates through all producers in arr and composes and returns one sorted
    // string
    public static String getSortedString(Producer[] arr) {
        String myString = "";
        for (int i = 0; i < arr.length; i++)
            myString += arr[i].getProducedStr();
        return sortString(myString);
    }

    // iterates through all consumers in arr and composes and returns one sorted
    // string
    public static String getSortedString(Consumer[] arr) {
        String myString = "";
        for (int i = 0; i < arr.length; i++)
            myString += arr[i].getConsumedStr();
        return sortString(myString);
    }

    // using the arguments given, produces and consumes values and then prints a
    // string if successful
    // buffer: the buffer that the producers and consumers will share
    // prodNum: number of producers
    // consNum: number of consumers
    // itemNum: number of items to be produced and then consumed
    // seed: the seed for the random values that will be produced
    public static void produceAndConsume(Bdbuffer buffer, int prodNum, int consNum, int itemNum, int seed) {
        Producer[] producers = fillProducers(buffer, prodNum, itemNum, seed);
        Consumer[] consumers = fillConsumers(buffer, consNum, itemNum);

        start(producers);
        start(consumers);

        join(producers);
        join(consumers);

        String prodString = getSortedString(producers);
        String consString = getSortedString(consumers);

        if (consString.equals(prodString))
            System.out.println("The sorted Produced and Consumed strings are the same as shown: " + consString);
    }
}