import java.util.Random;

/*********************************************************************************
 * Each instance of a producer generates a single character a-z randomly and
 * inserts it into the buffer, and reports the location and the time the number
 * was inserted into the buffer. Each letter added is appended to producedStr.
 ********************************************************************************/
public class Producer extends java.lang.Thread {
    // Necessary variables and object declaration
    Random randomWithSeed;// used to create random letters
    Bdbuffer buffer;// used to pass produced values to consumers
    int letterNum;// number of letters the producer will produce
    String producedStr;// contains all letters produced
    int id;// number used to differentiate each producer instance

    public Producer(Bdbuffer _buffer, int _letterNum, int _id, int _seed) {
        // Assign values to the variables
        randomWithSeed = new Random(_seed);
        buffer = _buffer;
        letterNum = _letterNum;
        producedStr = "";
        id = _id;
    }

    public String getProducedStr() {
        return producedStr;
    }

    @Override
    public void run() {
        // produce letterNum letters
        for (int i = 0; i < letterNum; i++) {
            // produce 1 letter
            char letter = (char) (this.randomWithSeed.nextInt(26) + 'a');

            // if enqueue is successful, add letter to producedStr
            if (buffer.enqueue(letter, id))
                producedStr += letter;
            // if unsuccessful, restart loop to try again
            else
                i--;
        }
    }
}
