#include <iostream>

using namespace std;

int main()
{
	cout << "one- because CU students are just like everybody else!" << '\n';
}
