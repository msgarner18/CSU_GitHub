#include "Enemy.h"
#include <cstring>
#include <iostream>
#include <vector>
#include <stdio.h>
#include <sys/types.h>
#include <pwd.h>
#include <fstream>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string>
#include <cassert>
#include <stdexcept>
#include <sstream>

using namespace std;

Gallery::Gallery(string fileName){}
void Gallery::read(string filename, string keyfilename){}
void Gallery::add(Enemy e){}
void Gallery::clear(){}
void Gallery::size(){}
void Gallery::empty(){}
void Gallery::get(size_t n){}
